package com.automationpractice.pages;

public class OrderHistory {

}
