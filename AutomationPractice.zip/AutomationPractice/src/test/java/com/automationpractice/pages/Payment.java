package com.automationpractice.pages;

public class Payment {

}
