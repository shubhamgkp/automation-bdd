package com.automationpractice.pages;

public class CartSummary {

}
