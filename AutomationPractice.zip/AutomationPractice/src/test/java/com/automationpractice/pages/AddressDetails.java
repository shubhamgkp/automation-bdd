package com.automationpractice.pages;

public class AddressDetails {

}
